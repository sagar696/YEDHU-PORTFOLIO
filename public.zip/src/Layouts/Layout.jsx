import React from "react";


const Layout = () =>{
  return(
<>
   <footer />


</>
  )

}

export default Layout;