import React, { useState, useEffect } from 'react';
import "./home.css";
import imgbg from '../../assets/img/home/homebg.png'
  

const Home = () =>{
   return(
       <div className="bg" >
    
    


       </div>
   )
}
export default Home;
