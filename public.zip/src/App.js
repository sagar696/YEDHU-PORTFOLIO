
import './App.css';
import '../src/assets/css/styles.css';
import Waitfor from './Components/common/waiting_for/waiting'
import AppDesign from './Components/App design/App_design';
import Footer from '../src/Components/footer/Footer';
import Preloader from './Components/preloader/loader'
import Project from '../src/Components/common/project_info/project'
import ImageSlider from '../src/Components/common/image_slider/slider'
import Websites from '../src/Components/Websites/Websites'
import Banner from '../src/Components/common/Banners/banner_websites';
import Ourservices from '../src/Components/Our Work/ourservices/service';
import Contactus from '../src/Components/Contact Us/Contact_us';


function App() {
  return (
    <div className="App">
 
   <Contactus/>
   

    </div>
  );
}

export default App;
