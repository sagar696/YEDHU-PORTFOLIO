import React from 'react';
import './copodeals.css';
import ReactDOM from 'react-dom';

const Copodeals = () =>{
    return(
      <div className="container">
        <div className="project_info">
        <span className="Project_Info_title">Project Info</span>
        </div>
      </div>
    )
}
export default Copodeals ;





