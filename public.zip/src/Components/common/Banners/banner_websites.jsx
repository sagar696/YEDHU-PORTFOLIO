import React from "react";
import image1 from '../../../assets/img/temporary/webdev@3x.png'
import './banner.css';

const Bannerimg = () =>{
    return(
        <>
        <div>
      <img src={image1}alt="Example" />
    </div>
        </>
    )
}
export default Bannerimg;