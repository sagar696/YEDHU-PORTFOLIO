import React from "react";
import './services.css';


const Services =()=>{
    return(
        <div className="container">
           <div className="section_title">
           <span className="sub_title"><span className="sub_title1" >We are</span> HashGate</span>
           </div> 
              <p className="about_content">
              We are a well-versed and established  IT Service Company, located in the fast-paced technology-driven wildlife of UAE, we are a multi-faceted company that caters to all things digital and technological. 
      Want to build a website for your business? We got you covered.
      Got big plans for a product you want to sell? We know the market, and we can help you with your plan.
      Looking for a team to help you manage your business? We have the men for that job. 
      We offer  a full spectrum of digital solutions, web services, media & content production that cater to every client’s specific needs. Whether you are an emerging startup or a seasoned industry powerhouse, our main expertise in IT, Media, Design, and multi-sectoral business solutions will help you achieve new heights in your business goals that you 
      never knew were possible.
      We are a one-stop destination for everything you need if you want to digitize and modernize your company. At HashGate, we always push the limits in IT solutions. We specialize in multiple services from Cross-platform development, Mobile Application Development, Web Development, UI-UX Design, Branding, Media, production, and many more. 
              </p>
              <div className="grid_development">
                
              </div>
        </div>
    )
}
export default Services;