import React from "react";

const SocialMedia = () =>{
    return(
        <>
        </>
    )
}
export default SocialMedia;