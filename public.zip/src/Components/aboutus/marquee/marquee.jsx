import React, { useRef, useEffect } from 'react';

const MarqueeSlider =() =>{
  return(
    <>
    </>
  )
}

export default MarqueeSlider;