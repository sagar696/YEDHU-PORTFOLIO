import React from "react";
import img01 from '../../assets/img/team/ancil.png';
import img02 from '../../assets/img/team/borna.png';
import img03 from '../../assets/img/team/neethu.png';
import img04 from '../../assets/img/team/sundas.png';

const Team = () =>{
    return(
        <>
        </>
    )
}
export default Team;